local VFX = script:GetCustomProperty("VFX")

function UsedBoost() 
	tracker = 0
	World.SpawnAsset(VFX)
	local cam = Game.GetLocalPlayer():GetDefaultCamera()
	local fov = cam.fieldOfView
	
	local i = 0
	while (i < 10) do
		cam.fieldOfView = cam.fieldOfView + 2
		Task.Wait(0.01)
		i = i + 1
	end
	Task.Wait(0.7)
	i = 0
	while (i < 10) do
		cam.fieldOfView = cam.fieldOfView - 2
		Task.Wait(0.01)
		i = i + 1
	end
end

Events.Connect("PlayerUsedBoost", UsedBoost)