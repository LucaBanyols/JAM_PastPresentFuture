local timerText = script.parent

local timerActive = false
local timer = 0
local finalTime = -1
function OnStateChange(old, new, hasTime, time)
	if (old ~= new and new == 1) then
		timer = 0
		finalTime = -1
		timerActive = true
	elseif (old ~= new and new == 2) then
		timerActive = false
	elseif (old ~= new and new == 0) then	
		finalTime = 0
	end 
end 

function formatTime(t)
	local s = ""
	local sec = CoreMath.Round(t, 2)
	if (sec < 10) then s = s .. "0" end
	
	s = s .. tostring(sec)
	
	return s
end 

function Tick(dt)
	if (timerActive) then
		timer = timer + dt
		local s = formatTime(timer)
		timerText.text = s 
	end 
	
	if (finalTime > 0) then
		timerText.text = formatTime(finalTime)
	elseif (finalTime == 0) then
		timerText.text = ""
	end 
end 

function OnFinalTime(t)
	finalTime = t
end 

Events.Connect("GameStateChanged", OnStateChange)
Events.Connect("FinalTime", OnFinalTime)