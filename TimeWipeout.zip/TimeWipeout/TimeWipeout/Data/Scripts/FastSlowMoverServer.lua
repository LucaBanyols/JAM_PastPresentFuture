local MOVER = script.parent

local propMoveTo = MOVER:GetCustomProperty("MoveTo")
local propMoveDuration1 = MOVER:GetCustomProperty("MoveDuration1")
local propMoveDuration2 = MOVER:GetCustomProperty("MoveDuration2")
local propObjectToMove = MOVER:GetCustomProperty("ObjectToMove"):WaitForObject()
local propWaitIntervalOrigin = MOVER:GetCustomProperty("WaitIntervalOrigin")
local propWaitIntervalMoveTo = MOVER:GetCustomProperty("WaitIntervalMoveTo")

local originPos = nil

function Init()
    originPos = propObjectToMove:GetWorldPosition()
end

function Tick(deltaTime)
    if propObjectToMove:GetWorldPosition() == originPos then
        Task.Wait(propWaitIntervalOrigin)
        propObjectToMove:MoveTo(propMoveTo, propMoveDuration1, false)
    end

    if propObjectToMove:GetWorldPosition() == propMoveTo then
        Task.Wait(propWaitIntervalMoveTo)
        propObjectToMove:MoveTo(originPos, propMoveDuration2, false)
    end
end

Init()
