local TRAIL = script:GetCustomProperty("Trail")
local trails = {}

function OnPlayerJoined(player)
	local newTrail = World.SpawnAsset(TRAIL)
	newTrail:AttachToPlayer(player, "root")
	newTrail:SetPosition(Vector3.New(0, 0, -42))
	trails[player.id] = newTrail
end

function OnPlayerLeft(player)
	trails[player.id]:Destroy()
	trails[player.id] = nil
end

Game.playerJoinedEvent:Connect(OnPlayerJoined)
Game.playerLeftEvent:Connect(OnPlayerLeft)