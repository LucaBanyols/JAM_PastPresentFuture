-- ItemController
-- By: WaveParadigm



-- Custom Properties
local itemUseCooldown = script:GetCustomProperty("ItemUseCooldown")
local boostMinimum = script:GetCustomProperty("BoostMinimumSpeed")
local boostMaximum = script:GetCustomProperty("BoostMaximumSpeed")
local fireballBaseSpeed = script:GetCustomProperty("FireballBaseSpeed")
local fireballBlastRadius = script:GetCustomProperty("FireballBlastRadius")

-- Templates
local BOOST_VFX = script:GetCustomProperty("BoostVFX")
local BOOST_SFX = script:GetCustomProperty("BoostSFX")
local FIREBALL = script:GetCustomProperty("Fireball")
local HOMING_FIREBALL = script:GetCustomProperty("HomingFireball")
local FIREBALL_EXPLOSION = script:GetCustomProperty("FireballExplosion")
local DID_HIT_SFX = script:GetCustomProperty("DidHitSFX")

-- Instance Variables
local players = {}
local playerList = {}

-- AttemptItem() is the function that gets called upon a player using ability_primary
-- First, it checks what item the player has by reading the "Item" resource property on the player
-- Default list of items:
--    0: No item.   1: Single boost.    2: 2 boosts.    3: 3 boosts.    4: Fireball.      5: Homing Fireball.
-- Depending on the value of the resource, relevant code will be executed.
function AttemptItem(player)
	local currentItem = player:GetResource("Item")
	if currentItem > 0 and (players[player]["itemLockout"] <= 0) then 
		players[player].itemLockout = itemUseCooldown
		
		if (currentItem >= 1 and currentItem <= 3) then
			Boost(player, currentItem)
		elseif (currentItem == 4) then	
			local f = LaunchFireball(player, FIREBALL)
			f.gravityScale = 0.3
		elseif (currentItem == 5) then	
			local f = LaunchFireball(player, HOMING_FIREBALL)			
			SeekOwner(f)
		end
	end
end

-- Take their current velocity, and increase it considerably. 
function Boost(player, currentItem)
	local v = player:GetVelocity()
	local xyv = Vector3.New(v.x, v.y, 0)
	local size = xyv.size
	local forward = player:GetWorldTransform():GetForwardVector()
	
	local minSize = boostMinimum
	local maxSize = boostMaximum
	local mult = 1.25
	
	if (size > maxSize) then
		player:SetVelocity(forward * size + Vector3.New(0, 0, v.z))
	elseif (size <= minSize) then
		player:SetVelocity(forward * minSize + Vector3.New(0, 0, v.z))
	else 
		player:SetVelocity(forward * size * mult + Vector3.New(0, 0, v.z))
	end
	
	
	local res = nil
	local err = nil
	while res ~= BroadcastEventResultCode.SUCCESS do
		--print("Sending event?")
		res, err = Events.BroadcastToPlayer(player, "PlayerUsedBoost")
		--print(res)
		if (res ~= BroadcastEventResultCode.SUCCESS) then
			print(err)
			Task.Wait(0.1)
		end
	end
	
	local vfx = World.SpawnAsset(BOOST_VFX)
	vfx:AttachToPlayer(player, "root")
	local sfx = World.SpawnAsset(BOOST_SFX)
	sfx:AttachToPlayer(player, "root")
	player:SetResource("Item", currentItem - 1)
end 	

-- Launches a fireball with specified parameters, and hooks up listeners for its destruction
function LaunchFireball(player, template)
	local launchDir = Rotation.New(0, 0, player:GetViewWorldRotation().z)
	local forward = launchDir * Vector3.FORWARD
	local hit = World.Raycast(player:GetWorldPosition(), player:GetWorldPosition() + Vector3.New(0, 0, -200), {ignorePlayers = player})
	local hit2 = World.Raycast(player:GetWorldPosition() + (forward * 50), player:GetWorldPosition() + (forward * 50) + Vector3.New(0, 0, -200), {ignorePlayers = player})
	
	local z = 0
	if (hit ~= nil and hit2 ~= nil) then
		local diff = hit2:GetImpactPosition() - hit:GetImpactPosition()
		z = diff:GetNormalized().z
	end 
	
	local launchDir = Rotation.New(0, 0, player:GetViewWorldRotation().z)
	local launchVec = launchDir * Vector3.New(1, 0, 0)
	local f = Projectile.Spawn(template, player:GetWorldPosition() + Vector3.New(0, 0, 250), Vector3.New(launchVec.x, launchVec.y, z))
	f.owner = player 
	f.gravityScale = 0
	f.speed = player:GetVelocity().size + fireballBaseSpeed
	players[player]["fireballImpactEvent"] = f.impactEvent:Connect(SpawnExplosion)
	players[player]["fireballImpactEvent2"] = f.lifeSpanEndedEvent:Connect(SpawnExplosion)
	player:SetResource("Item", 0)
	
	return f
end 

-- Destroys the currently active player Fireball, spawns an explosion effect, and checks within a radius
-- for players to knock up into the air.
function SpawnExplosion(projectile, other, hit)
	players[projectile.owner]["fireballImpactEvent"]:Disconnect()
	players[projectile.owner]["fireballImpactEvent2"]:Disconnect()
	local spawnPosition = projectile:GetWorldPosition()
	if (hit ~= nil) then spawnPosition = hit:GetImpactPosition() end
	
	World.SpawnAsset(FIREBALL_EXPLOSION, {position = spawnPosition})
	local hitPlayers = Game.FindPlayersInSphere(spawnPosition, fireballBlastRadius, {ignorePlayers = projectile.owner})
	if (#hitPlayers > 0) then
		World.SpawnAsset(DID_HIT_SFX):AttachToPlayer(projectile.owner, "root")
		for _,p in pairs(hitPlayers) do
			ExplodePlayer(p)
		end 
	end
end

-- The homing 
function SeekOwner(proj)
	proj.homingAcceleration = 3000
	while (Object.IsValid(proj) and not Object.IsValid(proj.homingTarget)) do
		local nearbyPlayers = Game.FindPlayersInSphere(proj:GetWorldPosition(), 1000, {ignorePlayers = proj.owner})
		if (#nearbyPlayers > 0) then
			proj.homingTarget = nearbyPlayers[1]
			proj.drag = 1.5
			return
		end 
		Task.Wait(0.1)
	end
	return
end

function ExplodePlayer(p)
	-- Perform this in a separate thread so it does't block execution
	Task.Spawn(function()
		-- Kick them off their mount, stop their velocity, put them in the death animation
		p:SetMounted(false)
		p.animationStance = "unarmed_death"
		p:ResetVelocity()
		
		p:SetResource("Item", 0) -- remove item
		
		Task.Wait(0.2)
		
		-- Ragdoll them and knock them into the air
		p:EnableRagdoll("lower_spine", .4)
		p:EnableRagdoll("right_shoulder", .6)
		p:EnableRagdoll("left_shoulder", .6)
		p:EnableRagdoll("right_hip", .6)
		p:EnableRagdoll("left_hip", .6)
		p:SetVelocity(Vector3.New(0, 0, 8000))
		
		Task.Wait(3)
		
		-- Put them back to normal
		p:DisableRagdoll()
		p.animationStance = "unarmed_stance"
		p:SetMounted(true)
	end)
end 

function Tick(dt)
	for _,p in pairs(playerList) do
		if (Object.IsValid(p) and p ~= nil and p.animationStance ~= "unarmed_death" and players[p] ~= nil) then
			if (players[p].itemLockout >= 0) then
				players[p].itemLockout = players[p].itemLockout - dt
			end 
		end 
	end
end 

function SetupPlayer(player)
	if (players[player] == nil) then
		players[player] = {}
	end 
	
	players[player].itemLockout = itemUseCooldown
end 

function OnBindingPressed(whichPlayer, binding)
	if (binding == "ability_primary") then 
		AttemptItem(whichPlayer)
	end
end

function OnPlayerJoined(player)
	player.bindingPressedEvent:Connect(OnBindingPressed)
	SetupPlayer(player)
	playerList[#playerList + 1] = player
end

function OnPlayerLeft(player)
	for i,p in pairs(playerList) do
		if (p.id == player.id) then
			playerList[i] = nil
		end
	end
end

Game.playerJoinedEvent:Connect(OnPlayerJoined)
Game.playerLeftEvent:Connect(OnPlayerLeft)