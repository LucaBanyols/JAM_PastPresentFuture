
local ROOT = script.parent
local TRIGGER = ROOT:FindChildByType("Trigger")


function OnBeginOverlap(trigger, other)
	if other:IsA("Trigger") then
		local pathScript = other.parent:FindChildByType("Script")
		
		if pathScript and pathScript.context.GetNext then
			local nextPoint = pathScript.context.GetNext(other)
			
			if nextPoint then
				local moveTime = nextPoint:GetCustomProperty("MoveTime") or 2
				local rotateTime = nextPoint:GetCustomProperty("RotateTime") or moveTime
				
				ROOT:MoveTo(nextPoint:GetWorldPosition(), moveTime)
				ROOT:RotateTo(nextPoint:GetWorldRotation(), rotateTime)
			end
		end
	end
end

TRIGGER.beginOverlapEvent:Connect(OnBeginOverlap)

TRIGGER.isEnabled = false
Task.Wait()
TRIGGER.isEnabled = true