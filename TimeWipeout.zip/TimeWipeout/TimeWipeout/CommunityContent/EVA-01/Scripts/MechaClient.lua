local HEAD = script:GetCustomProperty("HEAD"):WaitForObject()
local BODY = script:GetCustomProperty("BODY"):WaitForObject()
local SHOULDERL = script:GetCustomProperty("SHOULDERL"):WaitForObject()
local ARMUPPERL = script:GetCustomProperty("ARMUPPERL"):WaitForObject()
local ARMLOWERL = script:GetCustomProperty("ARMLOWERL"):WaitForObject()
local HANDL = script:GetCustomProperty("HANDL"):WaitForObject()
local CALFL = script:GetCustomProperty("CALFL"):WaitForObject()
local THIGHL = script:GetCustomProperty("THIGHL"):WaitForObject()
local FEETL = script:GetCustomProperty("FEETL"):WaitForObject()

local SHOULDERR = script:GetCustomProperty("SHOULDERR"):WaitForObject()
local ARMUPPERR = script:GetCustomProperty("ARMUPPERR"):WaitForObject()
local ARMLOWERR = script:GetCustomProperty("ARMLOWERR"):WaitForObject()
local HANDR = script:GetCustomProperty("HANDR"):WaitForObject()
local CALFR = script:GetCustomProperty("CALFR"):WaitForObject()
local THIGHR = script:GetCustomProperty("THIGHR"):WaitForObject()
local FEETR = script:GetCustomProperty("FEETR"):WaitForObject()

local player = Game.GetLocalPlayer()


function WearSuit()
	HEAD:AttachToPlayer(player,"neck")
	BODY:AttachToPlayer(player,"upper_spine")
	
	SHOULDERL:AttachToPlayer(player,"left_clavicle")
	ARMUPPERL:AttachToPlayer(player,"left_shoulder")
	ARMLOWERL:AttachToPlayer(player,"left_elbow")
	HANDL:AttachToPlayer(player,"left_wrist")
	
	THIGHL:AttachToPlayer(player,"left_hip")
	CALFL:AttachToPlayer(player,"left_knee")
	FEETL:AttachToPlayer(player,"left_ankle")
	
	SHOULDERR:AttachToPlayer(player,"right_clavicle")
	ARMUPPERR:AttachToPlayer(player,"right_shoulder")
	ARMLOWERR:AttachToPlayer(player,"right_elbow")
	HANDR:AttachToPlayer(player,"right_wrist")
	
	THIGHR:AttachToPlayer(player,"right_hip")
	CALFR:AttachToPlayer(player,"right_knee")
	FEETR:AttachToPlayer(player,"right_ankle")

end

WearSuit()