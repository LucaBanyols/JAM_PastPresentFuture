--[[

Kitbashed soley by Antropy for submission to the Scifi Spaceship & Mech Jam of 2020
By adding it to Community Contest, I have made this open source for you to use in your projects. I just ask that you give credit if you don't change any of it. Keeping this file
attached is sufficient credit, however, a shoutout in your game description would be awesome! Thanks & Enjoy!

]]--