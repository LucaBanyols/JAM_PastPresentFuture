local ROOT = script.parent.parent
local ABGS = require(script:GetCustomProperty("API"))
local VICTORY_SFX = script:GetCustomProperty("VictorySFX")
local index = -1
local isFinishLine = script:GetCustomProperty("IsFinishLine")
if (not isFinishLine) then
	index = ROOT:GetCustomProperty("CheckpointIndex")
else 
	Task.Wait(0.5)
	local checkpoints = World.FindObjectsByName("RaceCheckpointServer")
	local highestIndex = -1
	for _,c in pairs(checkpoints) do
		local ind = c.parent.parent:GetCustomProperty("CheckpointIndex")
		if (ind > highestIndex) then
			highestIndex = ind
		end 
	end 
	index = highestIndex + 1
end 
local LAP_SFX = script:GetCustomProperty("LapSFX")

local totalLaps = ROOT:GetCustomProperty("TotalLaps") or 3

local trigger = script.parent

function OnBeginOverlap(whichTrigger, other)
	if other:IsA("Player") then
		local playerCurrentCheckpoint = other:GetResource("Checkpoint")
		if (playerCurrentCheckpoint == index - 1) then
			if (not isFinishLine) then
				-- regular checkpoint: set Checkpoint resource to our index
				-- print("Set checkpoint to " .. tostring(index))
				other:SetResource("Checkpoint", index)
			else 
				-- Finish line. Increase lap counter, set checkpoint to 0. If at max laps, finish race.
				local playerCurrentLap = other:GetResource("Lap")
				local newLap = playerCurrentLap + 1
				other:SetResource("Lap", newLap)
				other:SetResource("Checkpoint", 0)
				-- print("Set lap to " .. tostring(playerCurrentLap + 1))
				if (LAP_SFX) then
					local lapSfx = World.SpawnAsset(LAP_SFX)
					lapSfx:AttachToPlayer(other, "root")
				end 
				
				if (newLap >= totalLaps) then
					-- YOU WIN
					if (ABGS.GetGameState() == ABGS.GAME_STATE_ROUND) then
						ABGS.SetGameState(ABGS.GAME_STATE_ROUND_END)
						World.SpawnAsset(VICTORY_SFX)
						Events.BroadcastToAllPlayers("BannerMessage", other.name .. " wins!")
						Task.Wait(5)
						ABGS.SetGameState(ABGS.GAME_STATE_LOBBY)
						local players = Game.GetPlayers()
						local killServer = World.FindObjectByName("KillZoneServer")
						for _,p in pairs(players) do
							p:SetResource("Checkpoint", 0)
							p:SetResource("Lap", 0)
							p:SetResource("Item", 0)
							killServer.context.RespawnPlayer(p, true)
						end 
					end 
				else 
					-- We haven't won yet, broadcast a Message Banner event to just that player informing them what lap this is
					local lapNames = { "Second", "Third", "Fourth", "Fifth", "Sixth", "Seventh", "Eighth", "Ninth", "Tenth" }
					local lapName = "Final Lap!"
					if (newLap < totalLaps - 1) then
						-- Not the final lap. If we can pull from lapNames do so, otherwise default to "Lap X!"
						if (newLap <= #lapNames) then
							lapName = lapNames[newLap] .. " Lap!"
						else 
							lapName = "Lap " .. tostring(newLap + 1) .. "!"
						end 
					end 
					Events.BroadcastToPlayer(other, "BannerMessage", lapName, 2.5)
				end 
			end 
		else 
			-- you somehow hit the wrong checkpoint.
			-- since this will be an invalid lap, just kill the player sending them back to their last valid checkpoint
			local killServer = World.FindObjectByName("KillZoneServer")
			killServer.context.RespawnPlayer(other, false)
			Events.BroadcastToPlayer(other, "BannerMessage", "You missed a checkpoint!", 2.5)
		end 
	end
end

trigger.beginOverlapEvent:Connect(OnBeginOverlap)

--If we are the final lap checkpoint, show the checkerboard banner.
local lapCube = ROOT:FindDescendantByName("LapCube")
if (lapCube and isFinishLine) then
	lapCube.visibility = Visibility.INHERIT
end 