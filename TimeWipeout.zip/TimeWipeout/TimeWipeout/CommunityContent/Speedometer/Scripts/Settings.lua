
-- to edit the settings do the following:
--	1. select the [Settings] object
--	2. go to the [Properties] tab
--	3. go to the [Custom] section
--	4. edit the values to whatever you like
