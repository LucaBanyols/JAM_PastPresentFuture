local needles = script.parent:FindDescendantsByName("Needle")
local brakeTextUI = script.parent:FindDescendantsByName("Brake Text")[1]
local player = Game.GetLocalPlayer()
local topSpeed = 10000
local rand = RandomStream.New()
local brakeText = "[Brake Engaged]"
local brakeDisplay = false

function Tick(dt)
	local vel = player:GetVelocity()
	local xyVel = Vector3.New(vel.x, vel.y, 0)
	local currentSpeed = xyVel.size
	local targetAngle = CoreMath.Lerp(180, 380, CoreMath.Clamp(currentSpeed / topSpeed, 0, 1))
		if (brakeTextUI) then
		if (brakeDisplay) then
			brakeTextUI.text = brakeText
		else 
			brakeTextUI.text = ""
		end 
	end
end 

function OnBindingPressed(p, b)
	if (b == "ability_feet") then
		brakeDisplay = true
	end 
end 

function OnBindingReleased(p, b)
	if (b == "ability_feet") then
		brakeDisplay = false
	end 
end 

-- Wait for a bit, then attach to local player's brake pressed
player.bindingPressedEvent:Connect(OnBindingPressed)
player.bindingReleasedEvent:Connect(OnBindingReleased)