local img = script.parent

local wipeTime = .2
local x = img.width
local isOn = false
local isActive = false

function wipeIn()
	local i = 0
	while (i < wipeTime) do
		img.x = CoreMath.Lerp(x, -500, i / wipeTime)
		i = i + 0.01
		Task.Wait(0.01)
	end
	
	isOn = true
end

function wipeOut()
	local i = 0
	while (i < wipeTime) do
		img.x = CoreMath.Lerp(-500, (-1 * x) - 500, i / wipeTime)
		i = i + 0.01
		Task.Wait(0.01)
	end
	
	isOn = false
end	

function OnStateChange(old, new, hasTime, time)
	if (old ~= new and new == 2) then --enter end state
		isActive = true
		Task.Wait(2.25 + wipeTime)
		wipeIn()
		Task.Wait(2 + wipeTime)
		wipeOut()
		Task.Wait(wipeTime)
		isActive = false
	end
end

function OnRespawn()
	if (not isActive) then
		wipeIn()
		Task.Wait(wipeTime + 0.25)
		wipeOut()
		Task.Wait(wipeTime)
	end
end 

Events.Connect("GameStateChanged", OnStateChange)
Events.Connect("MarbleRespawn", OnRespawn)