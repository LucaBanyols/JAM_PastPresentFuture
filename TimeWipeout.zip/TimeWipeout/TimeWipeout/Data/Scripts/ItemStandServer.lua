-- ItemStandServer
-- By: WaveParadigm

-- This script moderates what item to give to a player once they run over this Item Stand.
-- It'll pull a random integer from firstOptions, secondOptions, or thirdOptions depending 
-- on if you're in first, second, or 3rd/beyond.
-- Feel free to tweak these probability tables as you'd like, or add more around line 43.

local trigger = script.parent
local rand = RandomStream.New()
local sfx = script:GetCustomProperty("SFX")
local vfx = script:GetCustomProperty("VFX")
local visual = script:GetCustomProperty("Visual"):WaitForObject()

-- Config
local respawnDelay = script:GetCustomProperty("RespawnDelay") or 7


visual:RotateContinuous(Rotation.New(100, 100, 100))
local canHit = true

-- Probability tables for first, second, and third+. Third+ will be in effect always if there are <= 2 players.
-- The more times you put a particular int in the table, the more likely it will come up.
local firstOptions = { 1, 2 }
local secondOptions = { 1, 2, 5, 1, 3, 1, 1 }
local thirdOptions = {1, 5, 1, 3, 1, 1, 1, 1, 5, 2, 1}

local checkpoints = {}

-- bool ComparePlayers(Player, Player)
-- Comparing function that sets the sorting order
function ComparePlayers(player1, player2)
    local lap1 = player1:GetResource("Lap")
    local lap2 = player2:GetResource("Lap")
    
    local checkpoint1 = player1:GetResource("Checkpoint")
    local checkpoint2 = player2:GetResource("Checkpoint")
    
    local total1 = (lap1 * 10000) + checkpoint1
    local total2 = (lap2 * 10000) + checkpoint2
   
    if total1 ~= total2 then
        return total1 > total2
    end
    
    -- players are tied; compare distance to next checkpoint
    local nextCheckpoint = getCheckpointByIndex(checkpoint1 + 1)
    if (nextCheckpoint ~= nil) then
    	local ncp = nextCheckpoint:GetWorldPosition()
    	local dist1 = (player1:GetWorldPosition() - ncp).size
    	local dist2 = (player2:GetWorldPosition() - ncp).size
    	if (dist1 ~= dist2) then
    		return dist1 < dist2 -- the smaller distance wins
    	end 
    end

    -- Use name to ensure consistent order for players that are tied
    return player1.name < player2.name
end

function OnBeginOverlap(whichTrigger, other)
	if other:IsA("Player") and canHit then
		canHit = false
		local player = other
		local currentPower = player:GetResource("Item")
		if (currentPower == 0) then
			-- Bestow powerup
			local players = Game.GetPlayers()
			table.sort(players, ComparePlayers)
			local placement = -1
			for i,p in ipairs(players) do
				if (p.id == player.id) then
					placement = i 
				end 
			end 
						
			local options = thirdOptions
			if (placement == 1 and #players > 2) then
				options = firstOptions
			elseif (placement == 2 and #players > 2) then	
				options = secondOptions
			end
			
			player:SetResource("Item", options[rand:GetInteger(1, #options)])
		end
		
		World.SpawnAsset(sfx, {position = script:GetWorldPosition()})
		World.SpawnAsset(vfx, {position = script:GetWorldPosition()})
		visual.visibility = Visibility.FORCE_OFF
		Task.Wait(respawnDelay)
		visual.visibility = Visibility.INHERIT
		canHit = true
	end
end

-- Keep Shuffling RNG for unpredictable items.
function Tick(dt)
	local newSeed = rand:GetInteger(1, 100000)
	rand = RandomStream.New(newSeed)
	Task.Wait(0.5)
end 

function getCheckpointByIndex(ind)
	if (checkpoints == nil or #checkpoints == 0) then
		return nil
	end 
	
	for _,c in pairs(checkpoints) do
		if (c:GetCustomProperty("CheckpointIndex") == ind) then
			return c 
		end 
	end 
	
	return nil
end 

trigger.beginOverlapEvent:Connect(OnBeginOverlap)

Task.Wait(1)
checkpoints = World.FindObjectsByName("RaceCheckpointServer")
local checkpointParents = {}
for _,c in pairs(checkpoints) do
	checkpointParents[#checkpointParents + 1] = c.parent.parent
end 

checkpoints = checkpointParents

