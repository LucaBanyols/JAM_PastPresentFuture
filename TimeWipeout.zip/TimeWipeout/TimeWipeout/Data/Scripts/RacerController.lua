-- RacerController
-- By: WaveParadigm
-- This Controller will add force to players over time as they move. Paired with special movement settings,
-- the script enables a nice, gradual buildup of speed that lends itself to racers.
-- Edit the speed cap by using Player Movement Settings, and edit how fast the player moves or how how high
-- they jump using the custom properties on this script.


-- Custom Properties

local MOVEMENT_FORCE = script:GetCustomProperty("MovementForce")
local JUMP_FORCE = script:GetCustomProperty("JumpForce")
local GRAVITY_OVERRIDE = 20
local PLAYER_SPARK = script:GetCustomProperty("PlayerSpark")
local EXPLOSION_TEMPLATE = script:GetCustomProperty("Explosion")
local ABGS = require(script:GetCustomProperty("API"))


-- Instance variables.
local playerList = {}
local players = {}
local playerSparks = {}

local rand = RandomStream.New()
local defaultGravity = 7

function OnPlayerJoined(player) 
	player.canMount = false
	player.shouldDismountWhenDamaged = false
	player.diedEvent:Connect(PlayerDied)
	player.respawnedEvent:Connect(PlayerRespawned)
	player.bindingPressedEvent:Connect(OnBindingPressed)
	player.bindingReleasedEvent:Connect(OnBindingReleased)
	local playerSpark = World.SpawnAsset(PLAYER_SPARK)
	playerSparks[player.id] = playerSpark
	playerSpark:AttachToPlayer(player, "root")
	playerSpark.visibility = Visibility.FORCE_OFF
	defaultGravity = player.gravityScale
	
	--Setup character
	SetupPlayer(player)
	playerList[#playerList + 1] = player
end

function OnPlayerLeft(player)
	playerSparks[player.id]:Destroy()
	for i,p in pairs(playerList) do
		if (p.id == player.id) then
			playerList[i] = nil
		end
	end
end

function PlayerDied(player)
	World.SpawnAsset(EXPLOSION_TEMPLATE, {position = player:GetWorldPosition(), scale = Vector3.New(5,5,5)})
end 

function PlayerRespawned(player)
	SetupPlayer(player)
	player:SetMounted(true)
end
 
function SetupPlayer(player)
	if (players[player] == nil) then
		players[player] = {}
	end
	players[player]["timeSinceGrounded"] = 0
	players[player]["drifting"] = false
	player:SetMounted(false)
	Task.Wait(0.2)
	player:SetMounted(true)
end 

function OnBindingPressed(player, binding)
	if (binding == "ability_extra_21") then
		players[player]["W"] = true
	elseif (binding == "ability_extra_30") then
		players[player]["A"] = true
	elseif (binding == "ability_extra_31") then
		players[player]["S"] = true
	elseif (binding == "ability_extra_32") then
		players[player]["D"] = true
	elseif (binding == "ability_extra_17") then
		AttemptJump(player)
	elseif (binding == "ability_extra_0") then
		local p = player:GetResource("Powerup")
		player:SetResource("Powerup", (p + 1) % 6)
	elseif (binding == "ability_feet") then	
		AttemptDrift(player, true)
	end
end

function OnBindingReleased(player, binding)
	if (binding == "ability_extra_21") then
		players[player]["W"] = false
	elseif (binding == "ability_extra_30") then
		players[player]["A"] = false
	elseif (binding == "ability_extra_31") then
		players[player]["S"] = false
	elseif (binding == "ability_extra_32") then
		players[player]["D"] = false
	elseif (binding == "ability_feet") then
		AttemptDrift(player, false)
	end
end

function IsWASDPressed(d)
	return (d["W"] or d["A"] or d["S"] or d["D"])
end

function PlayerGrounded(player)
	return players[player]["timeSinceGrounded"] < 0.2
end 

function AttemptJump(player)
	if PlayerGrounded(player) then
		local force = JUMP_FORCE
		local pv = player:GetVelocity()
		local ss = pv.sizeSquared
		if (ss > 100000000) then
			force = force * 1.35
		elseif (ss > 50000000) then
			force = force * 1.15
		end
		players[player]["timeSinceGrounded"] = 1
		
		-- Set Z velocity to jump strength for the next .15 seconds, this smooths out jumping right before going over a dune
		local i = 0
		while (i < 10) do
			pv = player:GetVelocity()
			player:SetVelocity(Vector3.New(pv.x, pv.y, force))
			i = i + 1
			Task.Wait(0.0125)
		end
	end
end

function AttemptDrift(player, starting)
	if (starting and PlayerGrounded(player) and not players[player]["drifting"]) then
		players[player]["drifting"] = true
	elseif (not starting and players[player]["drifting"]) then
		players[player]["drifting"] = false
	end
end 	

function Tick(dt)
	local state = ABGS.GetGameState()
	for _,p in pairs(playerList) do
		if (Object.IsValid(p) and p ~= nil and p.animationStance ~= "unarmed_death" and state > 0) then
			local dir = p:GetWorldTransform():GetForwardVector()
			local force = MOVEMENT_FORCE
			if not IsWASDPressed(players[p]) then
				force = force / 2
			end
			
			if (players[p]["drifting"]) then
				-- less movement force while drifting, but better movement
				force = force * 0.6
				p.defaultRotationRate = 200
				playerSparks[p.id].visibility = Visibility.INHERIT
			else 
				p.defaultRotationRate = 80
				
				playerSparks[p.id].visibility = Visibility.FORCE_OFF
			end 
			
			if not p.isGrounded then
				force = force * 0.66
				players[p]["timeSinceGrounded"] = players[p]["timeSinceGrounded"] + dt
			else 	
				players[p]["timeSinceGrounded"] = 0
			end
			p:AddImpulse(dir * force)
			
			if (players[p]["timeSinceGrounded"] > 3) then
				-- been in the air for a good few seconds, time to override with heavier gravity
				p.gravityScale = GRAVITY_OVERRIDE
			else 
				p.gravityScale = defaultGravity
			end 			
		end
	end
end

Game.playerJoinedEvent:Connect(OnPlayerJoined)
Game.playerLeftEvent:Connect(OnPlayerLeft)