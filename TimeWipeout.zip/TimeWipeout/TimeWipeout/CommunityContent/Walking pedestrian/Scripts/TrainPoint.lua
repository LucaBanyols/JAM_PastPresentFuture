
local points = nil


function GetNext(object)
	Init()
	
	return points[object]
end

function Init()
	if points ~= nil then return end
	
	points = {}
	
	local children = script.parent:GetChildren()
	
	local first = nil
	local last = nil
	
	for i,child in ipairs(children) do
		if child:IsA("Trigger") then
			if first == nil then
				first = child
			end
			
			if last ~= nil then
				points[last] = child
			end
			
			last = child
		end
	end
	
	if last then
		points[last] = first
	end
end
