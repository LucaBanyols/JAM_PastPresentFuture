function OnPlayerJoined(player)
	player:SetVisibility(false,false)	
end

Game.playerJoinedEvent:Connect(OnPlayerJoined)


