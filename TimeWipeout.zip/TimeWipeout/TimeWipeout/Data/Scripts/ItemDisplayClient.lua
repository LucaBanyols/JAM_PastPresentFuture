local frame = script:GetCustomProperty("Frame"):WaitForObject()
local iconGroup = script:GetCustomProperty("Icons"):WaitForObject()
local icons = iconGroup:GetChildren()
local counter = script:GetCustomProperty("Counter"):WaitForObject()
local name = script:GetCustomProperty("PowerupName"):WaitForObject()
local prompt = script:GetCustomProperty("Prompt"):WaitForObject()
local player = Game.GetLocalPlayer()
local powerup = 0

local images = { script.parent:GetCustomProperty("Image1"), 
				script.parent:GetCustomProperty("Image2"), 
				script.parent:GetCustomProperty("Image3"),
				script.parent:GetCustomProperty("Image4"),
				script.parent:GetCustomProperty("Image5") }

local itemNames = { CoreString.Split(script.parent:GetCustomProperty("ItemNames"), ",") }
				
function DimIcons(alpha)
	for _,i in pairs(icons) do
		local cc = i:GetColor()
		i:SetColor(Color.New(cc.r, cc.g, cc.b, alpha))
	end
	local cc = frame:GetColor()
	frame:SetColor(Color.New(cc.r, cc.g, cc.b, alpha))
end
				
function Tick(dt)
	local currentItem = player:GetResource("Item")
	--[[
		0 = no powerup
		1 = single boost
		2 = double boost
		3 = triple boost
		4 = regular projectile
		5 = homing projectile
	]]--
	if (currentItem == nil or currentItem <= 0) then
		for _,i in pairs(icons) do
			i.visibility = Visibility.FORCE_OFF
		end
		name.text = ""
		prompt.text = ""
		counter.text = ""
		DimIcons(0)
	elseif (currentItem >= 1 and currentItem <= 3) then
		for _,i in pairs(icons) do
			i.visibility = Visibility.INHERIT
			i:SetImage(images[currentItem])
		end 
		name.text = itemNames[currentItem]
		prompt.text = "MB1"
		counter.text = tostring(currentItem)
		if (frame:GetColor().a == 0) then DimIcons(1) end
	elseif (currentItem >= 4) then 
		for _,i in pairs(icons) do
			i.visibility = Visibility.INHERIT
			i:SetImage(images[currentItem])
		end 
		name.text = itemNames[currentItem]
		prompt.text = "MB1"
		counter.text = ""
		if (frame:GetColor().a == 0) then DimIcons(1) end
	end 
	
	if (currentItem < powerup) then
		-- we used an item
		DimIcons(0.25)
		Task.Wait(0.5)
		if (player:GetResource("Item") > 0) then
			DimIcons(1)
		end
	end
	
	powerup = currentItem
	
	Task.Wait(0.1)
end 

function OnBindingPressed(whichPlayer, binding)
	if (binding == "ability_primary") and powerup > 0 then 
		DimIcons(0.25)
	end
end

player.bindingPressedEvent:Connect(OnBindingPressed)
