--[[ 				Urban/Scifi Background Buildings Kit 1.0

This Building is part of the Urban/Scifi Background Buildings Kit 1.0

Some parts of this structure use Lau scripts.  If you Mesh Merge
those parts they will stop working. 

-Chaz Scholton (XRSTudio)

]]--