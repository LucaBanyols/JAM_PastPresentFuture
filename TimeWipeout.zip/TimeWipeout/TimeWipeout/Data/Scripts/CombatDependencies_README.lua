--[[
	Combat Dependencies - Template
	v1.0.1
	by: standardcombo
	
	Add a copy of the Combat Dependencies template to the hierarchy.
--]]