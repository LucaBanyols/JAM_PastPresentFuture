--[[
Copyright 2019 Manticore Games, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the Software without restriction, including without limitation the
rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit
persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the
Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
--]]

-- Internal custom properties
local COMPONENT_ROOT = script:GetCustomProperty("ComponentRoot"):WaitForObject()
local CONTAINER = script:GetCustomProperty("Container"):WaitForObject()
local PANEL = script:GetCustomProperty("Panel"):WaitForObject()
local LINE_TEMPLATE = script:GetCustomProperty("LineTemplate")

-- User exposed properties
local HIDE_AT_ROUND_END = COMPONENT_ROOT:GetCustomProperty("HideAtRoundEnd")

-- Constants
local LOCAL_PLAYER = Game.GetLocalPlayer()
local FRIENDLY_COLOR = Color.New(0.0, 0.25, 1.0)
local ENEMY_COLOR = Color.New(1.0, 0.0, 0.0)

-- Variables
local currentPlayers = {}
local playerTimes = {}
local playerLines = {}
local atRoundEnd = false


-- nil OnPlayerJoined(Player)
-- Add a line to the scoreboard when a player joins
function OnPlayerJoined(player)
    local newLine = World.SpawnAsset(LINE_TEMPLATE, {parent = PANEL})
    newLine.y = newLine.height * (#playerLines + 1)
    -- print("New line for " .. player.name)
    --table.insert(playerLines, newLine)
    playerLines[#playerLines + 1] = newLine
end

-- nil OnPlayerLeft(Player)
-- Remove a line when a player leaves
function OnPlayerLeft(player)
    playerLines[#playerLines]:Destroy()
    playerLines[#playerLines] = nil
    -- print("Destroyed line.")
end

-- nil OnRoundStart()
-- Handles showing the scoreboard if HideAtRoundEnd is selected
function OnRoundStart()
    atRoundEnd = false
end

-- nil OnRoundEnd()
-- Handles hiding the scoreboard if HideAtRoundEnd is selected
function OnRoundEnd()
    atRoundEnd = true
end

-- bool ComparePlayers(Player, Player)
-- Comparing function that sets the sorting order
function ComparePlayers(player1, player2)
	local p1time = playerTimes[player1.name]
	local p2time = playerTimes[player2.name]
	if (p1time == nil or p1time == "-1") then
		p1time = 999999
	else 
		p1time = tonumber(p1time)
	end 

	if (p2time == nil or p2time == "-1") then
		p2time = 999999
	else 
		p2time = tonumber(p2time)
	end 
	
	
	
    -- Second we use kills
    if p1time ~= p2time then
        return p1time < p2time
    end

    -- Use name to ensure consistent order for players that are tied
    return player1.name < player2.name
end

-- nil Tick(float)
-- Update visibility and displayed information
function Tick(deltaTime)
	local checkPlayers = Game.GetPlayers()
	-- ensure checkPlayers and currentPlayers match
	if (#checkPlayers > #currentPlayers) then
		-- somebody joined. find out who
		local joinedPlayers = {}
		for _,p in pairs(checkPlayers) do
			local alreadyHere = false
			for _,q in pairs(currentPlayers) do
				if (p.id == q.id) then
					alreadyHere = true 
					break
				end 
			end 
			if (not alreadyHere) then
				joinedPlayers[#joinedPlayers + 1] = p 
			end
		end 
		
		for _,p in pairs(joinedPlayers) do
			OnPlayerJoined(p)
		end 
	elseif (#checkPlayers < #currentPlayers) then
		print("Somebody left!")
		-- somebody left. find out who
		local leftPlayers = {}
		for _,p in pairs(currentPlayers) do
			local stillHere = false
			for _,q in pairs(checkPlayers) do
				print(q)
				print(p)
				if (not Object.IsValid(q) or not Object.IsValid(p)) then
					break
				end 
				if (p.id == q.id) then
					stillHere = true
					break
				end 
			end 
			
			if (not stillHere) then
				leftPlayers[#leftPlayers + 1] = p
			end 
		end 
		
		for _,p in pairs(leftPlayers) do
			OnPlayerLeft(p)
		end 
	end 
	
	currentPlayers = checkPlayers



    if not atRoundEnd then
        CONTAINER.visibility = Visibility.INHERIT
        local players = Game.GetPlayers()
        table.sort(players, ComparePlayers)
        PopulateLevelTimes()

        for i, player in ipairs(players) do
            local teamColor = FRIENDLY_COLOR

            if player ~= LOCAL_PLAYER and Teams.AreTeamsEnemies(player.team, LOCAL_PLAYER.team) then
                teamColor = ENEMY_COLOR
            end

            local line = playerLines[i]
            line:GetCustomProperty("Profile"):WaitForObject():SetImage(player)
            line:GetCustomProperty("Name"):WaitForObject().text = player.name
            line:GetCustomProperty("Name"):WaitForObject():SetColor(teamColor)
            --for n,t in pairs(playerTimes) do
            	--print(n .. ": " .. t)
            --end 
            if (playerTimes[player.name] ~= nil and playerTimes[player.name] ~= "-1") then
            	line:GetCustomProperty("KillsText"):WaitForObject().text = string.sub(playerTimes[player.name], 1, 5)    --tostring(player.kills)
            else
            	line:GetCustomProperty("KillsText"):WaitForObject().text = ""
            end 
        end
    else
        CONTAINER.visibility = Visibility.FORCE_OFF
    end

end

-- Initialize
local headerLine = World.SpawnAsset(LINE_TEMPLATE, {parent = PANEL})
headerLine:GetCustomProperty("Profile"):WaitForObject().visibility = Visibility.FORCE_OFF
headerLine:GetCustomProperty("Name"):WaitForObject().text = "Players"
headerLine:GetCustomProperty("KillsText"):WaitForObject().text = "Level Time"

--Game.playerLeftEvent:Connect(OnPlayerLeft)
--Game.playerJoinedEvent:Connect(OnPlayerJoined)

if HIDE_AT_ROUND_END then
    Game.roundStartEvent:Connect(OnRoundStart)
    Game.roundEndEvent:Connect(OnRoundEnd)
end

function OnTimesChanged(o, n)
	PopulateLevelTimes() 
end 

function PopulateLevelTimes()
	local timesString = script.parent.parent:GetCustomProperty("PlayerTimes")
	local playerTimePairs = {CoreString.Split(timesString, "|")}
	for _,s in pairs(playerTimePairs) do
		local split = {CoreString.Split(s, ",")}
		playerTimes[split[1]] = split[2]
	end 
end

script.parent.parent.networkedPropertyChangedEvent:Connect(OnTimesChanged)

