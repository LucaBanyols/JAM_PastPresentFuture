local TEXT = script.parent
local COPY = script.parent.parent

function Tick(dt)
	TEXT.text = COPY.text
end 