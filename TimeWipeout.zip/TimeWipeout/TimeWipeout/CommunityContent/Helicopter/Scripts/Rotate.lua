local propRotate = script:GetCustomProperty("Rotate")
local propRotate_this = script:GetCustomProperty("Rotate_this"):WaitForObject()

local spinRotation = propRotate
propRotate_this:RotateContinuous(spinRotation)