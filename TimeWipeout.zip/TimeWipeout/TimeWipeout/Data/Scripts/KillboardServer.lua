
local currentLevel = -1

function OnLevelStart(l)
	currentLevel = l
	local players = {}
	while (#players <= 0) do
		players = Game.GetPlayers()
		Task.Wait(0.5)
	end 
	local data = {}
	for _,p in pairs(players) do
		data[p.name] = Storage.GetPlayerData(p)
		if (data[p.name].times == nil) then
			data[p.name].times = {}
			Storage.SetPlayerData(p, data[p.name])
		end 
	end 
	
	local s = ""
	for p,d in pairs(data) do
		local t = d.times[currentLevel] -- get stored level time
		if (t == nil) then t = -1 end
		s = s .. p .. "," .. tostring(t) .. "|"
	end 
	script.parent:SetNetworkedCustomProperty("PlayerTimes", s)
end 	

--[[function OnPlayerJoin(player)
	OnLevelStart(currentLevel)
end 

Game.playerJoinedEvent:Connect(OnPlayerJoin)]]--
Events.Connect("LevelStart", OnLevelStart)