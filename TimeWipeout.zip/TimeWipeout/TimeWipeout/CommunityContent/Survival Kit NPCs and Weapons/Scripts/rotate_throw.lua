local root = script.parent

root:RotateContinuous(Vector3.New(0,20,0), true)