local sand = script:GetCustomProperty("Sand"):WaitForObject()
local player = Game.GetLocalPlayer()

function Tick(dt)
	local pv = player:GetVelocity()
	local pvxy = Vector3.New(pv.x, pv.y, 0)
	if (player.isGrounded and pvxy.size > 350) then
		sand:SetSmartProperty("Density", 10)
	else
		sand:SetSmartProperty("Density", 0)
	end
end