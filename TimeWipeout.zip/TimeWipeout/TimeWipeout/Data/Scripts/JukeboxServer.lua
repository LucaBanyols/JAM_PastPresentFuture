local rand = RandomStream.New(CoreMath.Round(os.time(), 0))
local tracker = rand:GetInteger(1, 20)

function OnStateChange(old, new, hasTime, time)
	if (old ~= new and new == 1) then
		-- entered game state
		tracker = tracker + 1
		script.parent:SetNetworkedCustomProperty("TrackNumber", tracker)
	elseif (old ~= new and new == 2) then
		-- entered end state
		script.parent:SetNetworkedCustomProperty("TrackNumber", 0)
	end
end

Events.Connect("GameStateChanged", OnStateChange)