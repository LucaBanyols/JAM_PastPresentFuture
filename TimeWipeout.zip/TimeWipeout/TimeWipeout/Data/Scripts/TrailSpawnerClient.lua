
local EXPLOSION = script:GetCustomProperty("Explosion")

function Tick(dt)
	for _,p in pairs(Game.GetPlayers()) do
		if (Object.IsValid(p) and p.isGrounded and p:GetVelocity().size > 500) then
			World.SpawnAsset(EXPLOSION, {position = p:GetWorldPosition() + Vector3.New(0, 0, -90)})
		end
	end
end